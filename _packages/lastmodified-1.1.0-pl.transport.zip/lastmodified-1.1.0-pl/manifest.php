<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for LastModified

1.1.0-pl - 2021-12-14
=====================
- Add exclude by id setting
- Refactor plugin code and logic
- Update README information and settings
- Update code style
- Some improvement.

1.0.10-pl
==============
- Add clear cache for all updated documents on OnDocFormSave
- Massive refactoring
- Update .gitignore

1.0.9-pl
==============
- Add contexts support
- Some improvements

1.0.8-pl
==============
- Add prevent on session variables names

1.0.7-pl
==============
- Add prevent handling for authorized users
- Some improvements

1.0.6-pl
==============
- Add update start page
- Some improvements

1.0.5-pl
==============
- Add update nesting level

1.0.4-pl
==============
- Parent 0 bugfix
- Some improvements

1.0.3-pl
==============
- Add update parent editedon functionality
- Some phpdoc annotation update

1.0.2-pl
==============
- Add response directive option
- Update lexicon files and docs
- Some improvements

1.0.1-pl
==============
- Add maxage and expires options
- Add HTTP protocol version
- Update lexicon files and docs

1.0.0-pl
==============
- Initial release
',
    'license' => 'MIT License

Copyright (c) 2018 Sergey Kudashev

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '--------------------
LastModified
--------------------
Author: Kudashev Sergey <kudashevs@gmail.com>
--------------------

This MODx Revolution plugin handles If-Modified-Since request header and returns Last-Modified response header
with the response code 304 when it is necessary (more info and site check on https://last-modified.com/en/)

--------------------
Feel free to suggest ideas/improvements/bugs on GitHub:
https://github.com/kudashevs/LastModified/issues
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ace9dad33473e38c46adae2318643cb6',
      'native_key' => 'lastmodified',
      'filename' => 'modNamespace/c95351565be4d34f8ec80b54c4cdf75f.vehicle',
      'namespace' => 'lastmodified',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '985d862e57507fff890e679f87b65f14',
      'native_key' => 'lastmodified.response',
      'filename' => 'modSystemSetting/c4d6799d9258f820437cf4b6127702f7.vehicle',
      'namespace' => 'lastmodified',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0517e0038d19225684763b879d989585',
      'native_key' => 'lastmodified.maxage',
      'filename' => 'modSystemSetting/51f940b23c343ea668b8a145ce90ad8f.vehicle',
      'namespace' => 'lastmodified',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '06d4fff67d7840fb0188904e3ca8a7c2',
      'native_key' => 'lastmodified.expires',
      'filename' => 'modSystemSetting/362b6f77e1bbc0daa78526d69361948e.vehicle',
      'namespace' => 'lastmodified',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cef3e4bbb6d557b6de86757034140f2c',
      'native_key' => 'lastmodified.update_parent',
      'filename' => 'modSystemSetting/1af6db5c5ae8b0881e45386594c033a3.vehicle',
      'namespace' => 'lastmodified',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a8173860f74a2b85e754c14ad7976480',
      'native_key' => 'lastmodified.update_level',
      'filename' => 'modSystemSetting/6cb91e36aeb6db6354e6f9c33ccb6ac7.vehicle',
      'namespace' => 'lastmodified',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c58c7c8e99b739658ba246b6a027386',
      'native_key' => 'lastmodified.update_start',
      'filename' => 'modSystemSetting/6e58e1d755b15bb3bdd9ccd879b10802.vehicle',
      'namespace' => 'lastmodified',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c421e627c26a9d42f5ad5515d11aedf',
      'native_key' => 'lastmodified.prevent_authorized',
      'filename' => 'modSystemSetting/4fc782ee1922ba67a50a2e0efe703e25.vehicle',
      'namespace' => 'lastmodified',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd38afab70854c4e0e64ad8f60ad16d72',
      'native_key' => 'lastmodified.prevent_session',
      'filename' => 'modSystemSetting/306b85f3cd0cc65d9f84be9a9ea3f79f.vehicle',
      'namespace' => 'lastmodified',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2422e68126d907b9bdcf85fd0d96afce',
      'native_key' => 'lastmodified.exclude',
      'filename' => 'modSystemSetting/39140d5f703fa5b13e565840432f6b79.vehicle',
      'namespace' => 'lastmodified',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'f529d4798683bc976541841384bc5b40',
      'native_key' => NULL,
      'filename' => 'modCategory/7ceebed438b4eafbfdfd807f9dbc42ae.vehicle',
      'namespace' => 'lastmodified',
    ),
  ),
);