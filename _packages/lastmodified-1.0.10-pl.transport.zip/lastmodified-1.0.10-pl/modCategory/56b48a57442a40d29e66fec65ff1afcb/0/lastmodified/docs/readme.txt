--------------------
LastModified
--------------------
Author: Kudashev Sergey <kudashevs@gmail.com>
--------------------

This MODx Revolution plugin handle request If-Modified-Since and return Last-Modified header
and 304 response code if necessary (more info and site check on https://last-modified.com/en/

--------------------
Feel free to suggest ideas/improvements/bugs on GitHub:
https://github.com/kudashevs/LastModified/issues