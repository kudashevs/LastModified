<?php
$_lang['area_lastmodified.main'] = 'Основные';

$_lang['setting_lastmodified.maxage'] = 'Значение Max age';
$_lang['setting_lastmodified.maxage_desc'] = 'Устанавлиает значение max-age для заголовка Cache-control в секундах. По умолчанию 3600.';
$_lang['setting_lastmodified.expires'] = 'Значение Expires';
$_lang['setting_lastmodified.expires_desc'] = 'Устанавливает значение Expires в формате текущее время плюс заданный отступ. По умолчанию 3600.';