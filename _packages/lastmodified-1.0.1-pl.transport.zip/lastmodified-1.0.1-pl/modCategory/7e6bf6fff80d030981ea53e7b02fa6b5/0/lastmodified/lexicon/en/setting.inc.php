<?php
$_lang['area_lastmodified.main'] = 'Main';

$_lang['setting_lastmodified.maxage'] = 'Max age value';
$_lang['setting_lastmodified.maxage_desc'] = 'Set value of max-age Cache-control header in seconds. Default is 3600.';
$_lang['setting_lastmodified.expires'] = 'Expires value';
$_lang['setting_lastmodified.expires_desc'] = 'Set value of Expires header current time offset in seconds. Default is 3600.';