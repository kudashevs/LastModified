--------------------
LastModified
--------------------
Author: Kudashev Sergey <kudashevs@gmail.com>
--------------------

This MODx Revolution plugin handles If-Modified-Since request header and returns Last-Modified response header
with the response code 304 when it is necessary (more info and site check on https://last-modified.com/en/)

--------------------
Feel free to suggest ideas/improvements/bugs on GitHub:
https://github.com/kudashevs/LastModified/issues
